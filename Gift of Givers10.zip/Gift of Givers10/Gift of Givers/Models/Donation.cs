﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfGivers.Models  // Changed namespace
{
    public class Donation
    {
        [Key]
        public int DonationID { get; set; }

        public string? UserID { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        [StringLength(50)]
        public string? DonationType { get; set; }

        public DateTime? DonationDate { get; set; }

        [StringLength(50)]
        public string? PaymentMethod { get; set; }

        [ForeignKey("UserID")]
        public virtual User? User { get; set; }
    }
}