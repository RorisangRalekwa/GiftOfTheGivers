﻿using GiftOfGivers.Models;
using System.ComponentModel.DataAnnotations;

namespace GiftOfGivers.Models
{
    public class ReliefProject
    {
        [Key]
        public int ProjectID { get; set; }

        [Required]
        [StringLength(100)]
        public string ProjectName { get; set; } = string.Empty;

        [StringLength(100)]
        public string? Location { get; set; }

        public DateOnly? StartDate { get; set; }

        public DateOnly? EndDate { get; set; }

        [StringLength(50)]
        public string? Status { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        // Navigation property for volunteers assigned to this project
        public virtual ICollection<Volunteer>? Volunteers { get; set; }
    }
}