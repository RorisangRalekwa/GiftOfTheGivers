﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfGivers.Models
{
    public class Volunteer
    {
        [Key]
        public int VolunteerID { get; set; }

        public string? UserID { get; set; } // Changed from int? to string?

        [StringLength(200)]
        public string? Skills { get; set; }

        [StringLength(100)]
        public string? Availability { get; set; }

        public int? AssignedProjectID { get; set; }

        [ForeignKey("UserID")]
        public virtual User? User { get; set; }

        [ForeignKey("AssignedProjectID")]
        public virtual ReliefProject? AssignedProject { get; set; }
    }
}