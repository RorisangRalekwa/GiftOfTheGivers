﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace GiftOfGivers.Models
{
    public class User : IdentityUser
    {
        [Required]
        [StringLength(100)]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        // Note: The following properties are inherited from IdentityUser:
        // - Id (string)
        // - UserName (string)
        // - Email (string)
        // - EmailConfirmed (bool)
        // - PhoneNumber (string)
        // - PhoneNumberConfirmed (bool)
        // - TwoFactorEnabled (bool)
        // - LockoutEnd (DateTimeOffset?)
        // - LockoutEnabled (bool)
        // - AccessFailedCount (int)

        
        [StringLength(50)]
        public string? Role { get; set; }

        
        public virtual ICollection<Donation>? Donations { get; set; }
        public virtual ICollection<Volunteer>? VolunteerActivities { get; set; }
    }
}