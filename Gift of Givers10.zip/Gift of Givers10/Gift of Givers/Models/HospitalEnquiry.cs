﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfGivers.Models
{
    public class HospitalEnquiry
    {
        [Key]
        public int EnquiryID { get; set; }

        [Required]
        [StringLength(100)]
        public string HospitalName { get; set; } = string.Empty;

        [StringLength(100)]
        public string? ContactPerson { get; set; }

        [StringLength(20)]
        public string? ContactNumber { get; set; }

        [StringLength(500)]
        public string? RequestDetails { get; set; }

        public DateTime? DateRequested { get; set; }
    }
}