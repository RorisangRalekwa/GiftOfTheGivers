﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfGivers.Models
{
    public class VerifyEmailViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;
    }
}