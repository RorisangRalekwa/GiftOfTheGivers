﻿using System.ComponentModel.DataAnnotations;

namespace GiftOfGivers.Models
{
    public class Disaster
    {
        [Key]
        public int DisasterID { get; set; }

        [Required]
        [StringLength(100)]
        public string DisasterName { get; set; } = string.Empty;

        [StringLength(100)]
        public string? Location { get; set; }

        public DateTime? DateOccurred { get; set; }

        [StringLength(50)]
        public string? Severity { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        [StringLength(50)]
        public string? Status { get; set; }
    }
}