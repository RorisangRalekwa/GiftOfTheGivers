﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GiftOfGivers.Models
{
    public class Schedule
    {
        [Key]
        public int ScheduleID { get; set; }

        public int? VolunteerID { get; set; }

        public int? ProjectID { get; set; }

        public DateTime? ScheduleDate { get; set; }

        [StringLength(100)]
        public string? Task { get; set; }

        [StringLength(50)]
        public string? Status { get; set; }

        [ForeignKey("VolunteerID")]
        public virtual Volunteer? Volunteer { get; set; }
    }
}