﻿using Microsoft.EntityFrameworkCore;
using GiftOfGivers.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace GiftOfGivers.Data // Make sure this matches your project
{
    public class AppDbContext : IdentityDbContext<User>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Donation> Donations { get; set; }
        public DbSet<Volunteer> Volunteers { get; set; }
        public DbSet<ReliefProject> ReliefProjects { get; set; }
        public DbSet<HospitalEnquiry> HospitalEnquiries { get; set; }
        public DbSet<Disaster> Disasters { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder); // Important for Identity

            // Your custom configurations
            modelBuilder.Entity<Volunteer>()
                .HasOne(v => v.AssignedProject)
                .WithMany(p => p.Volunteers)
                .HasForeignKey(v => v.AssignedProjectID)
                .OnDelete(DeleteBehavior.SetNull);
        }
    }
}