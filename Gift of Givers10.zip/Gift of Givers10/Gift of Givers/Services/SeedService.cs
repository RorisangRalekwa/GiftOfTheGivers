﻿using GiftOfGivers.Data;
using GiftOfGivers.Models;

namespace GiftOfGivers.Services
{
    public interface ISeedService
    {
        Task InitializeDataAsync();
    }

    public class SeedService : ISeedService
    {
        private readonly AppDbContext _context;

        public SeedService(AppDbContext context)
        {
            _context = context;
        }

        public async Task InitializeDataAsync()
        {
            // Add initial data if needed
            if (!_context.ReliefProjects.Any())
            {
                var projects = new List<ReliefProject>
                {
                    new ReliefProject { ProjectName = "Emergency Flood Relief", Location = "Durban", Status = "Active" },
                    new ReliefProject { ProjectName = "Winter Warmth Drive", Location = "Johannesburg", Status = "Planning" }
                };

                await _context.ReliefProjects.AddRangeAsync(projects);
                await _context.SaveChangesAsync();
            }
        }
    }
}