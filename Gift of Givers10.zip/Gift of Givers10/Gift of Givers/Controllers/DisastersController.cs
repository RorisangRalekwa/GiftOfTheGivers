﻿using GiftOfGivers.Data;
using GiftOfGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfGivers.Controllers
{
    public class DisastersController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<User> _userManager;

        public DisastersController(AppDbContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var disasters = await _context.Disasters.ToListAsync();
                return View(disasters);
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Unable to load incidents: {ex.Message}";
                return View(new List<Disaster>());
            }
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> ReportDisaster(Disaster disaster)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Disasters.Add(disaster);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Disaster reported successfully!";
                }
                catch (Exception ex)
                {
                    TempData["Error"] = $"Unable to report incident: {ex.Message}";
                }
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }
    }
}