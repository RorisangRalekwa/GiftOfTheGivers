﻿using GiftOfGivers.Data;
using GiftOfGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfGivers.Controllers
{
    public class VolunteersController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<User> _userManager;

        public VolunteersController(AppDbContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {
            try
            {
                var projects = await _context.ReliefProjects.ToListAsync();
                ViewBag.Projects = projects;
            }
            catch (Exception ex)
            {
                ViewBag.Projects = new List<ReliefProject>();
                TempData["Error"] = $"Unable to load volunteer projects: {ex.Message}";
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Signup(string skills, string availability, int? assignedProjectId)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                TempData["Error"] = "User not found. Please log in again.";
                return RedirectToAction("Index");
            }

            var existingVolunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserID == user.Id);

            if (existingVolunteer != null)
            {
                TempData["Error"] = "You are already registered as a volunteer.";
                return RedirectToAction("Index");
            }

            var volunteer = new Volunteer
            {
                UserID = user.Id, // This is now string (from Identity)
                Skills = skills,
                Availability = availability,
                AssignedProjectID = assignedProjectId
            };

            try
            {
                _context.Volunteers.Add(volunteer);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Unable to save volunteer profile: {ex.Message}";
                return RedirectToAction("Index");
            }

            TempData["Success"] = "Thank you for volunteering! We'll contact you soon.";
            return RedirectToAction("Index");
        }

        [Authorize]
        public async Task<IActionResult> MyProfile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var volunteer = await _context.Volunteers
                .Include(v => v.AssignedProject)
                .FirstOrDefaultAsync(v => v.UserID == user.Id);

            return View(volunteer);
        }
    }
}