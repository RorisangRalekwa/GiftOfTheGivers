﻿using GiftOfGivers.Data;
using GiftOfGivers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GiftOfGivers.Controllers
{
    public class DonationsController : Controller
    {
        private readonly AppDbContext _context;
        private readonly UserManager<User> _userManager;

        public DonationsController(AppDbContext context, UserManager<User> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {
            try
            {
                var disasters = await _context.Disasters.ToListAsync();
                ViewBag.Disasters = disasters;
            }
            catch (Exception ex)
            {
                ViewBag.Disasters = new List<Disaster>();
                TempData["Error"] = $"Unable to load incidents for donations: {ex.Message}";
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize]
        public async Task<IActionResult> Donate(decimal amount, string donationType, string paymentMethod, int? disasterId)
        {
            if (amount <= 0)
            {
                TempData["Error"] = "Amount must be positive.";
                return RedirectToAction("Index");
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                TempData["Error"] = "User not found. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            var donation = new Donation
            {
                UserID = user.Id,
                Amount = amount,
                DonationType = donationType,
                PaymentMethod = paymentMethod,
                DonationDate = DateTime.Now
                // Note: Your Azure Donations table doesn't have DisasterID
                // If you need this, you'll need to add it to the model
            };

            try
            {
                _context.Donations.Add(donation);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Unable to save donation: {ex.Message}";
                return RedirectToAction("Index");
            }

            TempData["Success"] = "Thank you for your donation!";
            return RedirectToAction("Index", "Home");
        }

        [Authorize]
        public async Task<IActionResult> MyDonations()
        {
            var user = await _userManager.GetUserAsync(User);
            var donations = await _context.Donations
                .Where(d => d.UserID == user.Id)
                .OrderByDescending(d => d.DonationDate)
                .ToListAsync();

            return View(donations);
        }
    }
}